# edp-backend

For testing locally please folllow the next steps:
- Install NodeJS and ngrok
- Clone the code
- Start NodeJS server locally (npm start)
- Start ngrok and match the port to the application port (in this case: ngrok http 3000)
- Copy the generated ngrok HTTPs url into the bot settings by navigating under Settings > Version > current version > Bot webhook base URL


  