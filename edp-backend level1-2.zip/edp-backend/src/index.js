const {
  logger,
  server: { port },
} = require('./bootstrap/constants');

require('./helpers/proto');
require('./bootstrap')
  .bootstrapApplication()
  .then(server => server.listen(port))
  .then(() => logger.log(`The application is up on port ${port}`));
