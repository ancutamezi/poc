// eslint-disable-next-line
String.prototype.format = function ({
  publicHolidays = '',
}) {
  return this.replace('[PUBLIC_HOLIDAYS]', publicHolidays);
};

String.prototype.allTrim = String.prototype.allTrim ||
     function(){
        return this.replace(/\s+/g,' ')
                   .replace(/^\s+|\s+$/,'');
     };
  
 Date.prototype.inPast = date => {
      return date < new Date(); 
  }