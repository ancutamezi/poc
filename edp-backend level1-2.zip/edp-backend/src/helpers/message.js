const generateTextRepliesFrom = (payload, content) => (payload.replies.push({
  type: 'text',
  delay: 0,
  content,
}));

const generateQuickRepliesFrom = content => ({
  type: 'quickReplies',
  content: {
    title: content.title,
    buttons: [
      {
        title: content.opt1,
        value: content.opt1,
      },
      {
        title: content.opt2,
        value: content.opt2,
      },
    ],
  },
});


const generateQuickRepliesFromData = (title, buttons) => {
  return {
    type: 'quickReplies',
    content: {
      title: title,
      buttons: buttons
    }
  }
};

const generateListFromData = vacations => {
  { 
    const listElements = vacations.map(vacation => { 
      return  { title: 'No ' + vacation.noDays + ' days', 
        subtitle: vacation.startDate + ' to ' + vacation.endDate}
      });
    return {
    type: 'list',
    content: {
      elements: listElements
    }
  }
  }
}


const generateListWithCancelButton = vacations => {
  { 
    const listElements = vacations.map(vacation => { 
      return  { title: 'No ' + vacation.noDays + ' days', 
        subtitle: vacation.startDate + ' to ' + vacation.endDate,
        buttons: [
          {
            title: 'Cancel Vacation',
            type: 'postback',
            value: `CANCEL_VACATION_${vacation.startDate}_${vacation.endDate}`
          },
        ]
      }});

    return {
    type: 'list',
    content: {
      elements: listElements
    }
  }
  }
}

const generateListWithRescheduleButton = vacations => {
  { 
    const listElements = vacations.map(vacation => { 
      return  { title: 'No ' + vacation.noDays + ' days', 
        subtitle: vacation.startDate + ' to ' + vacation.endDate,
        buttons: [
          {
            title: 'Reschedule Vacation',
            type: 'postback',
            value: `RESCHEDULE_VACATION_${vacation.startDate}_${vacation.endDate}`
          },
        ]
      }});

    return {
    type: 'list',
    content: {
      elements: listElements
    }
  }
  }
}

module.exports = {
  generateTextRepliesFrom,
  generateQuickRepliesFrom,
  generateListFromData,
  generateQuickRepliesFromData,
  generateListWithCancelButton,
  generateListWithRescheduleButton
};
