const { isUndefined } = require('lodash');

const generatePayload = (memory, properties) => {
  const payload = {
    replies: [],
    conversation: { memory: { ...memory } },
  };
  if (!isUndefined(properties)) {
    properties.forEach(object => {
      Object.defineProperty(payload.conversation.memory, object.key, {
        value: object.value,
        writable: true,
        enumerable: true,
      });
    });
  }
  return payload;
};

const calculateDaysBetweenDates = (startDate, endDate) => {    
  // To calculate the time difference of two dates 
  const diffInTime = endDate.getTime() - startDate.getTime(); 
    
  // To calculate the no. of days between two dates 
  return diffInTime / (1000 * 3600 * 24); 
}

const getDatesRange = (startDate, endDate) => {
  let dates = [],
  currentDate = startDate,
  addDays = function(days) {
    var date = new Date(this.valueOf());
    date.setDate(date.getDate() + days);
    return date;
  };
while (currentDate <= endDate) {
dates.push(new Date(currentDate).toString());
currentDate = addDays.call(currentDate, 1);
}
return dates;
};

const inPast = date => new Date() < date;

module.exports = {
  generatePayload,
  calculateDaysBetweenDates,
  getDatesRange,
  inPast
};
