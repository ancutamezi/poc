const axios = require('axios');
const {
  HOLIDAY_API_KEY, COUNTRY, YEAR
} = require('../bootstrap/constants');

const instance = axios.create({
    baseURL: 'https://holidayapi.com/v1/',
    timeout: 10000,
    headers: {
        'Content-Type': 'application/json'
      },
  });

//const holidayUrl = `https://holidayapi.com/v1/holidays?pretty&key=${HOLIDAY_API_KEY}&country=${COUNTRY}&year=${YEAR}`;

class HolidayRepository {
    getPublicHolidays() {
        return instance.get(`/holidays?pretty&key=${HOLIDAY_API_KEY}&country=${COUNTRY}&year=${YEAR}`)
        .then(result => {
          return result.data.holidays.filter(holiday => holiday.public === true).map(holiday => new Date(holiday.date.replace('2019', '2020')));
        })
    }
  }
  
  module.exports = {
    factory() {
      return new HolidayRepository();
    },
  };
  