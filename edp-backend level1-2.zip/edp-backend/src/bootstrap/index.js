const appContainer = require('./application-container')();
const { logger } = require('./constants');
const { bootstrapDomainDependencies } = require('./domain-modules');
const { startServer } = require('./server');

const bootstrapApplication = () =>
  new Promise(resolve => {
    appContainer.register({
      logger,
    });
    return resolve();
  })
    .then(() => bootstrapDomainDependencies(appContainer))
    .then(() => startServer(appContainer));


module.exports = {
  bootstrapApplication,
};
