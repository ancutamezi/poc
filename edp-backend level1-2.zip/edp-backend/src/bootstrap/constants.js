require('dotenv').config();

module.exports = Object.freeze({
  logger: {
    log: console.log,
    info: console.info,
    warn: console.log,
    error: console.error,
  },
  server: {
    port: process.env.PORT || 3000,
  },
  HOLIDAY_API_KEY: '82cec194-0832-4a61-ae83-75e3fc73dc2d',
  COUNTRY: 'PT',
  YEAR: '2019'
});
