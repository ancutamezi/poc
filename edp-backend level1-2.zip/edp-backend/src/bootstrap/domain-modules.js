const bootstrapDomainDependencies = appContainer => {
  appContainer.factory({
    holidaysRepository: require('../repositories/holidays-repository').factory,
    holidaysService: require('../services/holidays-service').factory
  });
};

module.exports = {
  bootstrapDomainDependencies,
};
