const app = require('express')();
const bodyParser = require('body-parser');
const cors = require('cors');
const express = require('express');
const path = require('path');
const { OK, BAD_REQUEST, INTERNAL_SERVER_ERROR } = require('http-status-codes');
const { logger } = require('./constants');

const startServer = applicationContainer => {
  applicationContainer.factory({
    router: require('../router').factory,
  });

  app.use(
    cors({
      origin: '*',
      methods: 'GET,HEAD,PUT,PATCH,POST,DELETE,OPTIONS',
      preflightContinue: false,
      optionsSuccessStatus: OK,
    }),
  );

  app.use(bodyParser.json());
  app.use(bodyParser.urlencoded({ extended: false }));
  app.use('/images', express.static(path.join(__dirname, '/public')));

  if (process.env.NODE_ENV === 'dev') {
    app.use((err, req, res) => {
      if (err) {
        logger.error(err);
        res.status(INTERNAL_SERVER_ERROR).json({ error: err });
        logger.error(`Unable to start the server due to an error ${err}`);
        process.exit(1);
      } else {
        res.status(BAD_REQUEST).json({});
      }
    });
  }

  app.use('/', applicationContainer.get('router'));
  return app;
};

module.exports = {
  startServer,
};
