module.exports = [require('./validate-dates'), require('./validate-user'), require('./show-vacations'), require('./cancel-vacation')];
