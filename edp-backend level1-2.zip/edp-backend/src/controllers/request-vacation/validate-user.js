const { generatePayload} = require('../../helpers/utils');
const {generateTextRepliesFrom } = require('../../helpers/message');

const validateUserController = () => {
  const validateUser = (req, res) => {
    const { memory, language } = req.body.conversation;
    const { vacationHistory, invalidUserMsg, successMsg } =  memory; 
    const payload = generatePayload(memory, [{ value: {} }]);
    const userId = memory['user-id'].raw;
    const userVacationDetails = vacationHistory.filter(userInfo => userInfo.userId === userId)[0];
    const validUsers = vacationHistory.map(userDetails => userDetails.userId);

    if(validUsers.includes(userId)) {
        generateTextRepliesFrom(payload, successMsg[language]);
        delete payload.conversation.memory.vacationHistory;
        delete payload.conversation.memory.userUnauthorized;
        payload.conversation.memory.vacationHistory = userVacationDetails;
        payload.conversation.memory.navigateToMenu = true;
    }
     else {
        generateTextRepliesFrom(payload, invalidUserMsg[language]);   
        payload.conversation.memory.userUnauthorized = true;
    }
    res.send(payload);
     }
  return validateUser;
};

module.exports = {
  method: 'POST',
  path: '/validateUser',
  name: 'validateUserController',
  handlerFactory: validateUserController,
};

