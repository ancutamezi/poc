const { generatePayload} = require('../../helpers/utils');
const {generateListFromData,   generateListWithCancelButton,generateListWithRescheduleButton } = require('../../helpers/message');
const e = require('express');

const showVacationsController = () => {
  const showVacations = (req, res) => {
    const { memory, language } = req.body.conversation;
    const { vacationHistory } =  memory; 
    const payload = generatePayload(memory, [{ value: {} }]);

// { userId: '1000',
//   remainingDays: '10',
//   scheduledVacations:
//    [ { startDate: '10/01/2020', endDate: '15/01/2020', noDays: '5' },
//      { startDate: '10/05/2020', endDate: '13/05/2020', noDays: '3' },
//      { startDate: '15/08/2020', endDate: '25/08/2020', noDays: '10' } ] }
   if(memory['current-flow'] === 'my-vacations') {
    payload.replies.push(generateListFromData(vacationHistory.scheduledVacations));
     } else {
    if(memory.topic !== undefined) {
     if(memory.topic.slug === 'fl-cancel-vacation'){  
        payload.replies.push(generateListWithCancelButton(vacationHistory.scheduledVacations));
     } else {
        payload.replies.push(generateListWithRescheduleButton(vacationHistory.scheduledVacations));
     }
    }
}
     res.send(payload);
    }
  return showVacations;
};

module.exports = {
  method: 'POST',
  path: '/showVacations',
  name: 'showVacationsController',
  handlerFactory: showVacationsController,
};

