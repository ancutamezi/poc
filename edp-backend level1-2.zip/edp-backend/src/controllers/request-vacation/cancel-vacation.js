const { generatePayload, calculateDaysBetweenDates } = require('../../helpers/utils');

const cancelVacationController = (logger, holidaysService) => {
  const cancelVacation = (req, res) => {
    const { memory } = req.body.conversation;
    const { vacationHistory, vacationData } =  memory; 
    const payload = generatePayload(memory, [{ value: {} }]);
    const { scheduledVacations } = vacationHistory;
 
    const canceledVacationDates = vacationData.match(/\d{4}\-\d{2}\-\d{2}/g);
    const canceledStartDate = new Date (canceledVacationDates[0]);
    const canceledEndDate = new Date (canceledVacationDates[1]);
    delete payload.conversation.memory.vacationHistory.scheduledVacations;
    const remainingDays = (+vacationHistory.remainingDays) + (+calculateDaysBetweenDates(canceledStartDate, canceledEndDate));
    payload.conversation.memory.vacationHistory.remainingDays = remainingDays;
    updatedVacations = scheduledVacations.filter(vacation => (vacation.startDate) != canceledVacationDates[0]);
    payload.conversation.memory.vacationHistory.scheduledVacations = updatedVacations;
    res.send(payload);
  }
  return cancelVacation;
};

module.exports = {
  method: 'POST',
  path: '/cancelVacation',
  name: 'cancelVacationController',
  handlerFactory: cancelVacationController,
};

