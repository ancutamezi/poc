const { generatePayload, calculateDaysBetweenDates, getDatesRange } = require('../../helpers/utils');
const { generateTextRepliesFrom } = require('../../helpers/message');

const validateDatesController = (logger, holidaysService) => {
  // After receiving the dates,
  // the bot should verify if the dates are valid. 
  // The employee should not be able to schedule vacations in the past or schedule more days then he has available. 
  // If the dates are “invalid”, the bot should inform the employee and ask for new dates.
  // The bot should also be able to inform the employee that the requested period includes Portuguese holidays. 
  // To evaluate if the request has holidays, the platform should be able to integrate with the public Holiday API - https://holidayapi.com/ (or equivalent).

  const validateDates = (req, res) => {
    const { memory, language } = req.body.conversation;
    const { vacationHistory, dateInPast, moreDaysThanAvailable, publicHolidays, successMessage, successMessageReschedule } =  memory; 
    const { source } = req.body.nlp;
    const payload = generatePayload(memory, [{ value: {} }]);
    const dates = source.match(/\d{4}\-\d{2}\-\d{2}/g);
    const startDate = new Date (dates[0]);
    const endDate = new Date (dates[1]);
    let rescheduleOldDates, oldStartDate, oldEndDate, updatedVacations, remainingDays;
    const { vacationData, isComingFromRescheduleFlow } = memory;
    const {scheduledVacations } = vacationHistory;
 
    //reschedule process
    if(isComingFromRescheduleFlow) {
      rescheduleOldDates = vacationData.match(/\d{4}\-\d{2}\-\d{2}/g);
      oldStartDate = new Date (rescheduleOldDates[0]);
      oldEndDate = new Date (rescheduleOldDates[1]);
      updatedVacations = scheduledVacations.filter(vacation => (vacation.startDate) != rescheduleOldDates[0]);

      delete payload.conversation.memory.vacationHistory.scheduledVacations;
      payload.conversation.memory.vacationHistory.scheduledVacations = updatedVacations;
      remainingDays = (+calculateDaysBetweenDates(oldStartDate, oldEndDate)) + (+vacationHistory.remainingDays);
    } 
    else {
      remainingDays = vacationHistory.remainingDays;
    }

  //1. Validate if the dates are in the past
  if(startDate.inPast(startDate) === false || endDate.inPast(endDate) === false) {
    //&& !endDate.inPast(endDate) && startDate < endDate
     //valid dates 
     //calculate the period between dates and compare it to the available days
     //2. Validate if it scheduled more days than available
        if(calculateDaysBetweenDates(startDate, endDate) <= remainingDays) {
           //validDates
           //verify if requested period includes Portughese holidays
           return holidaysService.getPublicHolidays()
           .then(holidays => {
            const range = getDatesRange(startDate, endDate);
            const intersection = holidays.filter(holiday => range.includes(holiday.toString()));
            if(intersection.length >0) {
            generateTextRepliesFrom(payload, publicHolidays[language].format({publicHolidays: intersection.join(',')}));   
            }
            if(isComingFromRescheduleFlow) {
              generateTextRepliesFrom(payload, successMessageReschedule[language]);   
            } 
            else {
            generateTextRepliesFrom(payload, successMessage[language]);   
            }
            payload.conversation.memory.isValidationReady = true;
            payload.conversation.memory.vacationHistory.scheduledVacations.push({ startDate: startDate.toISOString().slice(0,10),
            endDate: endDate.toISOString().slice(0,10), noDays: calculateDaysBetweenDates(startDate, endDate)})
            payload.conversation.memory.goToNextFlow = true;
            payload.conversation.memory.isValidationReady = true;
            payload.conversation.memory.vacationHistory.remainingDays = (+remainingDays) - (+calculateDaysBetweenDates(startDate, endDate));
            delete  payload.conversation.memory.isComingFromRescheduleFlow;
            res.send(payload);
           })
        }
        else {
          //more days than available
          generateTextRepliesFrom(payload, moreDaysThanAvailable[language]);
          delete  payload.conversation.memory.isComingFromRescheduleFlow;
        }
     } else {
    //invalid dates -> send text message dates in the past
        generateTextRepliesFrom(payload, dateInPast[language]);
        delete  payload.conversation.memory.isComingFromRescheduleFlow;
     }
    
     res.send(payload);
  }
  return validateDates;
};

module.exports = {
  method: 'POST',
  path: '/validateDates',
  name: 'validateDatesController',
  handlerFactory: validateDatesController,
};

