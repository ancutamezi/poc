const express = require('express');
const { OK } = require('http-status-codes');
const routes = require('../controllers');

const routerFactory = applicationContainer => {
  const router = express.Router();

  routes.forEach(r => {
    applicationContainer.factory({ [r.name]: r.handlerFactory });
    router[r.method.toLowerCase()](r.path, applicationContainer.get(r.name));
  });

  // This route is triggered when something bad happened in the builder
  router.post('/errors', (req, res) => res.sendStatus(OK));
  router.get('/status', (req, res) => res.sendStatus(OK));

  return router;
};

module.exports = {
  factory: routerFactory,
};
