class HolidayService {
    constructor(holidaysRepository) {
      this.holidaysRepository = holidaysRepository;
    }
  
    getPublicHolidays() {
      return this.holidaysRepository.getPublicHolidays();
    }

  }
  
  module.exports = {
    factory(holidaysRepository) {
      return new HolidayService(holidaysRepository);
    },
  };